import { Injectable } from '@angular/core';

@Injectable()
export class BookService {

  books: any = [
    { id: 1, name: "Java", price: 300 },
    { id: 2, name: "JavaScript", price: 250 },
    { id: 3, name: "Python", price: 300 },
    { id: 4, name: "C++", price: 300 }
  ]


  constructor() { }


  getBooks() {
    return this.books
  }
}
